PURE WATER PROTECT – WEB ASSETS V1.0

Use the supplied images as illustrative communication visuals unless a real
project/reference identity is separately documented.

Core website positioning:
- underwater/marine easy-to-clean surface protection
- biozidfreie Positionierung according to the existing source basis
- reduced adhesion / easier cleaning as the core story
- hull-zone and seasonal monitoring logic

Do NOT claim:
- universal antifouling efficacy
- guaranteed fuel savings
- universal fouling prevention
- universal lifetime
- environmental harmlessness
without corresponding evidence.

All project claims require object-specific verification, monitoring or release.
