# PURE Website – Curated Asset Package

Stand: 11.09.2026

Dieses Paket enthält **nur kuratierte Assets** aus den ausgewerteten Präsentationen. Es ist bewusst klein gehalten.

## Verbindliche Nutzung

### 01_APPROVED_PUBLIC_ILLUSTRATIVE
Darf für die Website als **illustrative / technische / Demonstrator-Darstellung** verwendet werden. Die im Manifest genannten Claim-Grenzen bleiben verbindlich.

### 02_CONDITIONAL_REFERENCE_RIGHTS
Inhaltlich wertvolle Referenzbilder, aber die bereitgestellten Unterlagen belegen **keine öffentliche Kunden-/Logo-/Bildfreigabe**. Nicht automatisch veröffentlichen. Erst verwenden, wenn das Projekt die Rechte/Referenzfreigabe bestätigt.

### 03_CONCEPT_ONLY
Nur als **Konzept / Entwicklung**. Nie als Serienprodukt, Kundenreferenz oder zertifizierte Lösung ausgeben.

## Nicht enthalten

- Pure Protect T730: regulatorische BPR-/Claim-Fragen offen.
- Historische BoatProtect-2017-Bilder/Claims: nicht freigegeben.
- Floor Protect: keine zusätzlichen Bilder nötig; Proof-Daten nativ als HTML/CSS darstellen.
- Hydrotox/DSLT: Evidence-Daten nativ darstellen, keine PowerPoint-Screenshots.
- IR-Paneel-Messdaten: Tabellen/Diagramme nativ aus TIPMS V2.1 / Website Master DB V1.2 umsetzen.

## Design-Regel

Keine komplette PowerPoint-Folie als Website-Grafik einsetzen. Bilder als Rohasset verwenden; technische Daten, Badges und Caveats nativ im Web bauen.

## Wichtig

Generated/illustrative imagery is not a documented reference. Reference imagery does not prove universal product performance. A/B/C/D status from the current master databases has priority over wording embedded in older decks.
