# PURE LIQUID HEAT — Controlled Asset Package V1.0

## Folder logic
- `01_REAL_INTERNAL`: actual internal/user images. Publication rights still need confirmation where noted.
- `02_DEVELOPMENT_CONCEPT`: development/design concepts. Must be visibly labelled `DEVELOPMENT CONCEPT` when used publicly.
- `03_BRANDING_CONCEPT`: concept imagery with third-party brands. Never present as customer references; rights/trademark clearance is required before public use.
- `04_TECHNICAL_SOURCE`: source graphics for technically controlled native web redraws. Do not use as claimed certification drawings.
- `99_SOURCE_ORIGINALS`: untouched image streams extracted from the source PDFs for traceability.

## Critical rules
1. Do not present concept renders as completed customer installations.
2. Do not infer Red Bull, Coca-Cola, BMW, AIDA, Heineken, McDonald's etc. as customers from branding concepts.
3. The current controlled Liquid Heat direct-substrate communication is limited to GFB / GFK / Vermiculite.
4. The corrected build-up is: substrate → Liquid Heat coating → contacting/sensors/safety → optional protective layer only where exposure requires it. No primer.
5. Technical-source images should be redrawn as native SVG/CSS/web graphics before final publication where possible.
6. Product-performance numbers embedded in concept boards are not automatically released website specifications.
