# QA CHECKLIST — MOTION ASSET GATE

Desktop 1440:
- hero copy readable throughout loop
- ambient effect visible but not dominant
- no obvious loop reset
- no layout shift
- no unsupported claim implied

Tablet 768:
- motion simplified where needed
- no scroll lag
- no clipped content

Mobile 390/360:
- poster/lightweight fallback where appropriate
- no navigation regression
- no delayed hero copy
- no heavy filter loop if avoidable

Reduced motion:
- ambient disabled
- static fallback remains premium

Product separation:
- Water = underwater/material-science, not yacht/lifestyle
- Boat = above-water premium marine surface, not Water
- Fire = heat behind barrier, not dramatic flames
- Liquid Heat = conductive path/surface warmth, not fire

Performance:
- no new large dependency
- no permanent JS loop if CSS/SVG suffices
- missing future media URLs never break hero
