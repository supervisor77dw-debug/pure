# MOTION SPECS

## Global technical specification
Preferred implementation order:
1. CSS gradients / masks / transforms
2. SVG masks / paths / filters, used sparingly
3. Existing approved still image + CSS light/reflection
4. Only if 1–3 are visibly insufficient: compressed external WebM + MP4 fallback

Future video envelope:
- maximum 1920×1080 desktop master
- 24 fps
- 8–20 second seamless loop
- muted, no embedded text
- WebM primary, MP4 fallback
- target <= 1.5 MB, hard target <= 2 MB
- WebP/AVIF poster
- never block hero text/LCP

Motion rules:
- one ambient auto-running effect per hero
- no obvious loop reset
- text contrast stable through entire loop
- disable motion under prefers-reduced-motion
- mobile defaults to poster or simplified CSS/SVG

## PURE WATER PROTECT
Visual objective: premium underwater refracted light on a dark technical surface.
No boat, fish, bubbles, coral, fouling-removal, tourism look or before/after.
Loop 14–20 s, subtle aqua/teal caustics, low brightness, dark stable copy area.
Mobile: poster or one/two gradient layers.

## PURE FIRE PROTECT
Visual objective: diffuse heat/ember motion behind a calm protective material layer.
No fireball, sparks storm, burning building or lab-test simulation.
Loop 12–16 s. Barrier visually stable.
Must not imply universal fire resistance, a specific class or PURE THERMO + PURE FIRE system performance.
Mobile: static ember gradient behind barrier.

## PURE BOAT PROTECT
Visual objective: refined above-water marine surface with subtle reflected water light.
Close-up deck/cockpit/material/fitting. No travel-ad look, large glamour yacht or third-party logos.
Loop 15–20 s, low-frequency blue reflection.
Must not imply antifouling, fuel savings, speed improvement or universal compatibility.
Mobile: still + subtle CSS reflection.

## PURE LIQUID HEAT
Do not create external media yet. Use SVG/CSS first:
electrical contact → conductive path → homogeneous surface warmth.
Must communicate electrical resistance heating, never energy creation.

## THERMO / SURFACE / FLOOR / WOOD
No external motion media before review:
- THERMO: neutral CSS/SVG thermal gradient
- SURFACE: CSS reflection sweep
- FLOOR: restrained reflection
- WOOD: still image + warm moving light
