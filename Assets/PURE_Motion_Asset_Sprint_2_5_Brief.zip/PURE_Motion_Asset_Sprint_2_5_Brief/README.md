# PURE Motion Asset Sprint 2.5 – Preparation Pack

Purpose: prepare the next visual enhancement step in parallel with Sprint 2, without spending image/video-generation credits before the current CSS/SVG hero implementation has been reviewed.

Priority candidates for external motion assets:
1. PURE WATER PROTECT – underwater caustics / refracted light
2. PURE FIRE PROTECT – heat/ember motion behind a protective layer
3. PURE BOAT PROTECT – premium marine reflected light

Important:
- Sprint 2 should first try CSS/SVG where specified.
- Do NOT create/download stock videos yet.
- Do NOT imply scientific measurement, certification, antifouling, fireproof performance, fuel savings, speed gains, or other unverified claims through motion.
- Mobile uses posters / simplified CSS/SVG by default.
- All future media must be language-neutral (no embedded text) so the same asset can be used for DE and EN.
- `prefers-reduced-motion` must always show a static premium fallback.
