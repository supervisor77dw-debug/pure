# GENERATION BRIEFS — use only after Sprint-2 visual review

## WATER
Premium material-science hero background for an advanced marine surface technology. Deep navy and graphite field with subtle underwater light caustics and refracted aqua highlights moving softly across a smooth technical surface. Elegant, minimal, architectural, dark enough for white website copy. No boats, fish, bubbles, coral, beach, people, text, logos, visible fouling or before/after effect. 16:9.

## FIRE
Premium deep-tech hero background showing a calm translucent protective material layer with soft heat and ember glow moving behind it. Front surface remains stable, dark graphite/navy, elegant and controlled. No burning building, fireball, sparks storm, test simulation, text, logos or claimed fire class. 16:9.

## BOAT
Premium close-up of a refined yacht or boat surface: deck, cockpit material, brushed metal fitting or high-quality marine panel, with soft blue reflected water light moving subtly across the surface. Understated luxury and material quality, not a travel advertisement. No large full-yacht glamour composition, people, brand logos, text, fuel/speed or antifouling implication. 16:9.

Future video encoding:
- 1920×1080
- 24 fps
- 12–20 s seamless loop
- no audio
- WebM + MP4
- <= 2 MB target
- no embedded copy, same asset for DE/EN
