PURE SURFACE PROTECT – WEB ASSETS

01_hero_facade_source_*
Source visual from MasterDeck page 1. Use as visual source/hero candidate; contains a conceptual split-treatment effect and should not be presented as a documented real before/after reference.

02_uae_case_*
Original embedded photographs from MasterDeck page 10, UAE bank marble facade case. Keep these as real case-study imagery. Before public use, confirm TII/PURE holds sufficient website usage rights and confirm how the before/after relation should be labelled.

03_UAE_case_layout_reference.png
Rendered slide 10 only as layout/reference for the coder. Do NOT publish the slide itself as the final website asset.

Still to create separately:
- technical cross-section: substrate -> ultra-thin hybrid matrix -> barrier/easy-clean principle
- premium infrastructure application visual
- premium industrial application visual

Source: 20260805_TII_PureSurfaceProtect_MasterDeck_2026_DE_UAE_Referenz_werblicher_v2.
