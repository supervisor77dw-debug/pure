PURE FINAL MOTION ASSETS

This package contains the two authored ambient assets approved for the next integration step:

PURE WATER PROTECT
- abstract underwater refracted-light / caustics ambience
- no text
- no tourism imagery
- no antifouling/self-cleaning implication

PURE LIQUID HEAT
- illustrative contact / conductive path / distributed warmth ambience
- no text
- no fire, coils or scientific measurement simulation
- no energy-saving or efficiency implication

Desktop:
WebM primary + MP4 fallback.

Mobile and prefers-reduced-motion:
static WebP poster.

The included CODER_INTEGRATION_PROMPT.txt is the binding integration scope.
