PURE BOAT PROTECT – WEB ASSETS V1.0

Core positioning:
- premium surface preservation for yachts and boats
- thin flexible hard coating / easy-to-clean logic
- zone-specific application: deck/cockpit, fenders/plastics, leather, metal/fittings
- object-specific substrate and compatibility checks are mandatory

Do not present illustrative yacht images as real customer references.
Do not claim:
- guaranteed three-year lifetime for every yacht
- universal Sikaflex compatibility
- universal UV/salt/weather resistance
- universal slip resistance or haptics
- universal suitability for every substrate
without appropriate evidence.

Recommended website visual gaps to create separately:
1. premium yacht hero visual
2. technical thin-layer / easy-to-clean cross-section
3. zone map of yacht surfaces
4. Teak/Sikaflex detail
5. cockpit/leather or metal/fittings detail
