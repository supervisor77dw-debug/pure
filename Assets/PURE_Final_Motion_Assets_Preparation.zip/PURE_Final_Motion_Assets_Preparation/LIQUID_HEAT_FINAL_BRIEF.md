# PURE LIQUID HEAT — FINAL AUTHORED MOTION BRIEF

## Objective
Create a premium technical motion composition that explains the principle:
electrical contact → conductive functional layer → controlled homogeneous surface warmth.

This must look like deep-tech material engineering, not a heater advertisement.

## Visual composition
- dark graphite / navy technical surface
- thin conductive functional layer
- two subtle electrical contact points or a clearly defined contact region
- controlled amber/orange path
- soft heat spread across the surface
- material remains solid and premium

## Motion sequence
1. 0–2 s: contact region activates subtly
2. 2–5 s: thin conductive path becomes visible
3. 5–8 s: warmth spreads softly across surface
4. 8–10/12 s: stable homogeneous warm state
5. transition invisibly back to start

## Visual rules
- no fire
- no sparks
- no coils
- no lava
- no glowing red-hot plate
- no exaggerated thermal-camera effect
- no numeric temperature values
- no apparent energy multiplication

## Claim boundary
The visual is illustrative only and must not imply:
- >100% efficiency
- lower electricity consumption by itself
- heat-pump superiority
- specific temperature or watt density
- certified electrical safety
- series-production approval

## Prompt for image/video generation
High-end deep-tech material-science hero animation for an ultra-thin conductive heating
surface. Dark graphite and navy technical material, subtle electrical contact region,
a fine controlled amber conductive path gradually energizing across a thin functional
layer, followed by soft homogeneous surface warmth. Elegant, minimal, precise, premium
engineering aesthetic. No fire, sparks, coils, glowing red-hot metal, thermal-camera
look, numbers, text or logos. The surface remains calm and materially realistic.
Cinematic 16:9, restrained motion.

## Poster frame
Use the stable warm-state frame:
- conductive path visible but subtle
- even warm gradient
- no hotspot behind hero copy
