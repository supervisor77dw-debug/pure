# PURE Final Motion Assets – Preparation Pack

This pack prepares the two authored visual assets selected after Sprint 3:

1. PURE WATER PROTECT
2. PURE LIQUID HEAT

No final video asset is included yet. The pack defines the exact visual brief,
technical constraints, filenames, fallback logic, and integration contract so
the assets can be produced and inserted without redesigning the site.

## Decision status
- WATER: external authored asset required
- LIQUID HEAT: external authored asset required
- FIRE: no external asset required
- BOAT: no external asset required

## Global rules
- language-neutral media only; no embedded text
- no unsupported performance implication
- no scientific-test simulation
- mobile uses poster/static fallback by default
- reduced-motion uses poster/static fallback
- hero text and CTA must remain readable at all frames
- asset must not block LCP
