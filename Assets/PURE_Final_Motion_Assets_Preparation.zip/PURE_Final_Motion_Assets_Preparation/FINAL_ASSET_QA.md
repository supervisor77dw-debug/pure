# FINAL ASSET QA

## WATER
- [ ] premium natural refraction
- [ ] not tourism/ocean-stock footage
- [ ] no fish/bubbles/coral/yacht
- [ ] no fouling-removal implication
- [ ] stable dark text zone
- [ ] seamless loop
- [ ] mobile poster works
- [ ] reduced-motion poster works

## LIQUID HEAT
- [ ] contact activation visible
- [ ] conductive path controlled
- [ ] warmth spreads across surface
- [ ] no fire/sparks/coils/lava
- [ ] no energy-amplification implication
- [ ] seamless loop
- [ ] mobile poster works
- [ ] reduced-motion poster works

## TECHNICAL
- [ ] WebM < 2 MB target
- [ ] MP4 fallback < 2 MB target where possible
- [ ] 1920×1080 max
- [ ] 24 fps
- [ ] no audio
- [ ] no embedded text
- [ ] LCP copy unaffected
- [ ] no layout shift
