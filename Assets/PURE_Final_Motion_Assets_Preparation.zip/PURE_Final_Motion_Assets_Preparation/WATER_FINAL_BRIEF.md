# PURE WATER PROTECT — FINAL AUTHORED MOTION BRIEF

## Objective
Create a premium, restrained hero ambience that feels like material science
underwater rather than travel, yacht lifestyle, or generic ocean footage.

## Visual composition
- deep navy / graphite technical surface
- soft refracted aqua/teal light
- slow underwater caustics
- dark stable copy zone
- elegant, architectural, controlled
- no identifiable environment required

## Motion
- seamless 14–20 s loop
- 24 fps
- slow displacement only
- no obvious loop reset
- caustics remain 5–10% visual dominance
- luminance variation must stay low enough for stable text contrast

## Must NOT include
- fish
- bubbles
- coral
- waves crashing
- beach/tourism imagery
- yacht
- visible fouling disappearing
- before/after self-cleaning effect
- logos
- text

## Claim boundary
The visual is purely atmospheric. It must not imply:
- antifouling approval
- fouling prevention
- self-cleaning
- fuel savings
- environmental certification
- measured hydrodynamic performance

## Prompt for image/video generation
Premium material-science hero background for an advanced marine surface technology.
Deep navy and graphite field with subtle underwater light caustics and refracted aqua
highlights moving softly across a smooth technical surface. Elegant, minimal,
architectural, dark enough for white website copy. No boat, fish, bubbles, coral,
beach, people, text, logos, visible fouling or before/after effect. High-end deep-tech
aesthetic, realistic but abstract, restrained motion, cinematic 16:9.

## Poster frame
Choose a frame with:
- calm caustics
- dark copy area
- no bright hotspot behind heading
