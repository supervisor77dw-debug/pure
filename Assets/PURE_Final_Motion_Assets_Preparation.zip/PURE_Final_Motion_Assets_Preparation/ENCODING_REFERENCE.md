# Encoding reference (optional, after master video exists)

## WebM
ffmpeg -i master.mp4 -an -vf "scale=1920:-2:force_original_aspect_ratio=decrease,fps=24" \
  -c:v libvpx-vp9 -b:v 0 -crf 36 -row-mt 1 -deadline good output.webm

## MP4 fallback
ffmpeg -i master.mp4 -an -vf "scale=1920:-2:force_original_aspect_ratio=decrease,fps=24" \
  -c:v libx264 -preset slow -crf 26 -movflags +faststart -pix_fmt yuv420p output.mp4

Tune CRF upward if necessary to meet the <=2 MB web target while preserving quality.
