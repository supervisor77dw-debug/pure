PURE WOOD PROTECT – WEB ASSETS V1.0

Core positioning:
- transparent wood-surface protection derived from the PURE Surface platform
- natural wood appearance remains central
- object- and species-specific release logic
- sample area is essential for colour, gloss, haptics, wetting and cleaning

Do not present illustrative split images as a real before/after reference.
Do not claim:
- universal wood preservative efficacy
- fungal/algal protection as a biocidal claim
- universal UV lifetime
- universal slip resistance
- universal suitability for all wood species
without appropriate evidence.

Recommended website visual gaps to create separately:
1. technical wood cross-section / thin hybrid matrix
2. premium architectural timber façade
3. terrace/deck application
4. high-value furniture/interior wood detail
